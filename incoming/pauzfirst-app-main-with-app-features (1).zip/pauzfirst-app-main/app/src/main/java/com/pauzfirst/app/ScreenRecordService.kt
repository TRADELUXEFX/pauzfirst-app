package com.pauzfirst.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.File

/**
 * Records a whole session in the background: your microphone plus the phone's own sound, and, when
 * "Record screen" is on, the screen too. Sound-only sessions are saved as audio, screen sessions as video.
 */
class ScreenRecordService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var sound: SessionAudio? = null
    private var videoFile: File? = null
    private var soundFile: File? = null
    private var withVideo = false
    private var finished = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        withVideo = intent.getBooleanExtra("video", false)
        startForegroundNow()
        val code = intent.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        }
        if (data == null || !SessionRecorder.hasMic(this)) {
            SessionRecorder.serviceOn = false
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            begin(code, data)
        } catch (e: Exception) {
            SessionRecorder.serviceOn = false
            cleanup()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNow() {
        val channel = "pauzfirst_record"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(channel, "Training recording", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channel) else Notification.Builder(this)
        val n = b.setContentTitle("Recording your training")
            .setContentText(if (withVideo) "The screen and all sound are being recorded" else "All sound is being recorded")
            .setSmallIcon(R.drawable.ic_stat_pauzfirst)
            .setColor(Ui.BLUE)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1002, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1002, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1002, n)
        }
    }

    private fun begin(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        // newer Android versions can hand back nothing (permission already used up): stop cleanly instead of crashing
        val p = mpm.getMediaProjection(code, data) ?: run { finish(); return }
        projection = p
        // Android 14 needs this callback before recording starts; it also fires if the user stops sharing
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                finish()
            }
        }, Handler(Looper.getMainLooper()))

        val stamp = SessionRecorder.stamp()
        // sound first: your mic mixed with the phone's own sound
        val sf = File(cacheDir, "pauzfirst_sound_" + stamp + ".m4a")
        soundFile = sf
        val s = SessionAudio(p) { Engine.isVoiceActive() }
        sound = s
        s.start(sf)

        if (withVideo) {
            val dm = resources.displayMetrics
            var w = dm.widthPixels
            var h = dm.heightPixels
            val scale = Math.min(1f, 720f / Math.min(w, h))
            w = ((w * scale).toInt() / 2) * 2
            h = ((h * scale).toInt() / 2) * 2
            val vf = File(cacheDir, "pauzfirst_video_" + stamp + ".mp4")
            videoFile = vf
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setOutputFile(vf.absolutePath)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            r.setVideoSize(w, h)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate(3000000)
            r.prepare()
            recorder = r
            display = p.createVirtualDisplay("pauzfirst", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            r.start()
        }
    }

    private fun cleanup() {
        try { display?.release() } catch (e: Exception) { android.util.Log.w("PauzFirst", "ScreenRecordService step failed", e) }
        display = null
        try { recorder?.release() } catch (e: Exception) { android.util.Log.w("PauzFirst", "ScreenRecordService step failed", e) }
        recorder = null
        try { projection?.stop() } catch (e: Exception) { android.util.Log.w("PauzFirst", "ScreenRecordService step failed", e) }
        projection = null
    }

    /** Stops everything, joins sound and video, and saves the result. Runs once. */
    private fun finish() {
        if (finished) return
        finished = true
        sound?.stop()
        var videoOk = withVideo
        if (withVideo) {
            try { recorder?.stop() } catch (e: Exception) { videoOk = false }
        }
        cleanup()
        SessionRecorder.serviceOn = false
        val sf = soundFile
        val vf = videoFile
        val soundOk = sound?.ok == true && sf != null && sf.exists()
        Thread {
            if (withVideo && videoOk && vf != null && vf.exists()) {
                val out = File(cacheDir, "pauzfirst_session_" + SessionRecorder.stamp() + ".mp4")
                if (soundOk && sf != null && SessionAudio.mux(vf, sf, out)) {
                    SessionRecorder.save(this, out, "video/mp4", true)
                    vf.delete()
                    sf.delete()
                } else {
                    // joining failed: keep the video and the sound as two files rather than lose either
                    SessionRecorder.save(this, vf, "video/mp4", true)
                    if (soundOk && sf != null) SessionRecorder.save(this, sf, "audio/mp4", false)
                }
            } else if (soundOk && sf != null) {
                SessionRecorder.save(this, sf, "audio/mp4", false)
            }
            Handler(Looper.getMainLooper()).post { stopSelf() }
        }.start()
    }

    override fun onDestroy() {
        if (!finished) finish()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
